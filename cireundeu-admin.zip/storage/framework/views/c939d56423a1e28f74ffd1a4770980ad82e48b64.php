
<?php $__env->startSection('title', 'Artikel'); ?>

<?php $__env->startSection('custom-style'); ?>;
<style>
.post-title {
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
    max-width: 500px;
}
</style>

<?php $__env->startSection('content'); ?>
<div class="row clearfix">
    <div class="col-12">
        <form action="<?php echo e(route('post.index')); ?>">
            <div class="input-group mb-3">
                <input type="text" class="form-control" placeholder="Cari judul artikel disini..." aria-describedby="searchButton" name="keyword">
                <div class="input-group-append">
                    <button class="btn btn-outline-primary" type="submit" id="searchButton">Search</button>
                </div>
            </div>
        </form>
    </div>

    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                <div class="row">
                    <div class="col-6 d-flex align-items-center">
                        <h2>Daftar Artikel</h2>
                    </div>
                    <div class="col-6 text-right">
                        <a href="<?php echo e(route("post.create")); ?>" class="btn btn-primary btn-sm">Tambah</a>
                    </div>
                </div>
            </div>
            <div class="body">
                <div class="table-responsive" id="family-table">
                    <table class="table table-hover m-b-0 c_list">
                        <thead>
                            <tr>
                                <th>Judul Artikel</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <p class="post-title mb-0"><?php echo e($post->title); ?></p>
                                    </td>

                                    <td>
                                        <form action="<?php echo e(route("post.destroy", $post->id)); ?>" method="POST" class="mb-0">
                                            <?php echo method_field('DELETE'); ?>
                                            <?php echo csrf_field(); ?>
                                            <a href="<?php echo e(route('post.show', $post->id)); ?>" class="btn btn-info" title="Show"><i class="fa fa-eye"></i></a>

                                            <a href="<?php echo e(route('post.edit', $post->id)); ?>" class="btn btn-success" title="Edit"><i class="fa fa-edit"></i></a>

                                            <button type="submit" class="btn btn-danger" title="Delete"><i class="fa fa-trash-o"></i></button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="mt-3">
                <?php echo e($posts->links()); ?>

            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>

    $('.sparkbar').sparkline('html', { type: 'bar' });

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL\Source Code\SC PKL\cireundeu-admin\resources\views/post/index.blade.php ENDPATH**/ ?>