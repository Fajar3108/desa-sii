<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="icon" href="<?php echo e(asset('images/logo-cirendeu.png')); ?>" type="image/x-icon"> <!-- Favicon-->
    <title><?php echo $__env->yieldContent('title'); ?> - <?php echo e(config('app.name')); ?></title>
    <meta name="description" content="<?php echo $__env->yieldContent('meta_description', config('app.name')); ?>">
    <meta name="author" content="<?php echo $__env->yieldContent('meta_author', config('app.name')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/bootstrap/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/font-awesome/css/font-awesome.min.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/components/auth.css')); ?>">
</head>
<body class="d-flex align-items-center justify-content-center">

<div class="card card-login" style="max-width: 800px;">
  <div class="row">
    <div class="col-md-6">
      <div class="card-body pl-5">
        <img src="<?php echo e(asset('images/logo-cirendeu.png')); ?>" class="card-logo mt-4" alt="Logo">
        <h1 class="card-title h1">Login</h1>
        <p class="card-text text-muted">Welcome back to Cirendeu Admin Panel</p>
        <hr>
        <form class="form-signin mb-5" action="<?php echo e(route('login')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="signin-username"><strong>Username</strong></label>
                <input type="text" class="form-control" id="signin-username" placeholder="Username" name="username">
                <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div class="form-group">
                <label for="signin-password"><strong>Password</strong></label>
                <input type="password" class="form-control" id="signin-password" placeholder="Password" name="password">
                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class="text-danger"><?php echo e($message); ?></small>
                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <button type="submit" class="btn btn-main btn-block text-white text-uppercase">Sign in</button>
        </form>
      </div>
    </div>
    <div class="col-md-6 card-image">
      <img src="https://raw.githubusercontent.com/darektoa/village-website/main/src/assets/images/profile/slide_3.jpeg" class="img-fluid rounded-start" alt="">
    </div>
  </div>
</div>

</body>
</html>
<?php /**PATH D:\ALL\Source Code\SC PKL\cireundeu-admin\resources\views/auth/login.blade.php ENDPATH**/ ?>