
<?php $__env->startSection('title', 'Keluarga'); ?>
<?php $__env->startSection('parentPageTitle', 'Penduduk'); ?>


<?php $__env->startSection('content'); ?>

<div class="row clearfix">

    <div class="col-lg-12">
        <div class="card">
            <div class="header">
                <p><a href="<?php echo e(route('citizen.index')); ?>">< Kembali</a></p>
                <h2 style="margin-bottom: 10px !important">Keluarga <span class="text-primary"><?php echo e($citizen->name); ?></span></h2>
                <p class="mb-0">No KK : <?php echo e($citizen->family->number); ?></p>
                <p class="mb-0">Jumlah anggota kelarga : <?php echo e($citizens->count()); ?></p>
            </div>
            <div class="body">
                <div class="table-responsive">
                    <table class="table table-hover m-b-0 c_list">
                        <thead>
                            <tr>
                                <th>Nama</th>
                                <th>Tanggal lahir</th>
                                <th>Alamat</th>
                                <th>Jenis kelamin</th>
                            </tr>
                        </thead>
                            <tbody>
                                <?php $__currentLoopData = $citizens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $citizen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($citizen->name); ?>

                                    </td>
                                    <td>
                                        <span><i class="zmdi"></i><?php echo e(date('d M Y' , strtotime($citizen->birthday))); ?></span>
                                    </td>
                                    <td>
                                        <span><i class="zmdi"></i><?php echo e($citizen->address); ?></span>
                                    </td>
                                    <td>
                                        <address><i class="zmdi zmdi-pin"></i><?php echo e($citizen->gender == 'L' ? 'Laki - laki' : 'Perempuan'); ?></address>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>

    $('.sparkbar').sparkline('html', { type: 'bar' });

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL\Source Code\SC PKL\cireundeu-admin\resources\views/citizen/show.blade.php ENDPATH**/ ?>