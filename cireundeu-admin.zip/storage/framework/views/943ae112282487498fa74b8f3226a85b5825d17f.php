<nav class="navbar navbar-fixed-top">
    <div class="container-fluid">
        <div class="navbar-btn">
            <button type="button" class="btn-toggle-offcanvas"><i class="lnr lnr-menu fa fa-bars"></i></button>
        </div>

        <div class="navbar-brand">
            <a href="<?php echo e(route('dashboard')); ?>"><img src="<?php echo e(asset('images/logo-cirendeu.png')); ?>" alt="Lucid Logo" class="img-responsive logo" style="width: 40px"></a>
        </div>

        <div class="navbar-right">
            <div id="navbar-menu">
                <ul class="nav navbar-nav">
                    
                    <li>
                        <form action="<?php echo e(route('logout')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger">Logout <i class="icon-login pl-1"></i></button>
                        </form>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</nav>
<?php /**PATH D:\ALL\Source Code\SC PKL\cireundeu-admin\resources\views/layout/navbar.blade.php ENDPATH**/ ?>