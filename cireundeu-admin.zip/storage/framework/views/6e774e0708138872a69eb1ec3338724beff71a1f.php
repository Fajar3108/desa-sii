
<?php $__env->startSection('title', 'Album'); ?>

<?php $__env->startSection('content'); ?>
<form action="<?php echo e(route('category.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="input-group mb-3">
        <input type="text" class="form-control" placeholder="Nama Album" aria-label="Recipient's username" aria-describedby="basic-addon2" name="name">
        <button class="btn btn-primary input-group-append">
            Tambah Album
        </button>
    </div>
</form>

<div class="row clearfix">
    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3 mb-4" >
        <a href="<?php echo e(route('category.show', $category->id)); ?>">
            <div class="card m-0 album-card"  style="height: 200px; background-color: #aaa;">
                <?php if(isset($category->galleries[$category->galleries->count() - 1]->image)): ?>
                <img src="<?php echo e(str_contains($category->galleries[$category->galleries->count() - 1]->image, "http") ? $category->galleries[$category->galleries->count() - 1]->image : asset('storage/' . $category->galleries[$category->galleries->count() - 1]->image)); ?>" class="card-img-top" alt="..." style="object-fit: cover; height: 100%">
                <?php endif; ?>
                <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST" class="position-absolute" style="top: 10px; right: 10px; z-index: 1">
                    <?php echo method_field('DELETE'); ?>
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-danger" title="Delete" onclick="handler(event)"><i class="fa fa-trash-o"></i></button>
                </form>
                <div class="card-img-overlay text-light rounded cat-cap" style="background-color: rgba(0,0,0,.5);">
                    <h5 class="card-title"><?php echo e($category->name); ?></h5>
                    <p class="card-text">Terdapat <?php echo e($category->galleries->count()); ?> gambar dalam album ini</p>
                </div>
            </div>
        </a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="mt-3">
        <?php echo e($categories->links()); ?>

    </div>
</div>

<script>
    function handler(e) {
        const result = confirm('Apa anda yakin ? semua gallery dengan category ini akan di hapus');

        if (!result) {
            e.preventDefault();
        }
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\ALL\Source Code\SC PKL\cireundeu-admin\resources\views/category/index.blade.php ENDPATH**/ ?>